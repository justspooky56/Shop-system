module.exports = { 
    Posts : {
        here : 50 , 
        every : 10 , 
    }, 

    ads : {
        'بدون منشن': '10',
        'منشن هير': '10', 
        'منشن ايفري ون': '10',
        'بروم الهداية': '10', 
        'روم خاص مع قيف اوي':'10', 
        'اول روم':'10', 
    }, 

    PrivteRoom : {
        Day7 : 20
    }, 
    Spin:
    {
        Basic: 10,
        Exclusive: 20
    },
    Mzad: {
        mzad: 10
    },
    RemoveWarns : {
     W25 : 10 , 
     W50 : 20
    },
    Transfer: {
        transfer : 10
    },
}