module.exports = {
    Spin: {
        Basic: {
            WinLog: '1333606277690953738', 
            Prizes: [
                'Nitro',
                '1000 Credits',
                'Special Role',
                'Emoji Pack',
                'Nothing'
            ]
        },
        Exclusive: {
            WinLog: '1333606277690953738', 
            Prizes: [
                'Nitro Boost',
                '5000 Credits',
                'Legendary Role',
                'Animated Banner',
                'Nothing'
            ]
        }
    }
};
