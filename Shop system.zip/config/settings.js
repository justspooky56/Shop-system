module.exports = {
    Owners: ["772207868152905788", "id2", "id3"], // الاونرات
    RoleCoOwner: 'رتبة مساعد الاونر',
    BankID: '1128175045223665755',
    Probot: '282859044593598464',
    red: 'http://localhost:5000',
    port: 5000,
    prefix: '$',
    لون_الامبيد: '#acb6c4',
    RommsShop: ["id1", "id", "id", "id", "id", "id", "id", "id", "id", "id", "id", "id", "id"], // هنا تحط ايدي الشعوب لو دول كتير امسح الزياده
    filterEnabled: false,

  bannedWords: [
    "متجر", "حساب", "بيع", "شراء", "شوب", "ديسكورد", "سعر", "متوفر", "بوست",
    "نيترو", "توكنات"
  ],

  wordReplacements: {
    "متجر": "متـgـر",
    "حساب": "7ـساب",
    "بيع": "بـيـ3",
    "شراء": "شـrـراء",
    "شوب": "شـ9ب",
    "ديسكورد": "ديسـkورد",
    "سعر": "سـ3ـر",
    "متوفر": "متـ9فر",
    "بوست": "بـ9ست",
    "نيترو": "نيـtـرو",
    "توكنات": "تـ9ـكنات"
  },
    RBPrefix: 'Tr',
    Rooms: {
        AuctionRoom: '1074547401429356545',
        PublishedAuctions: '1074547487014125609',
        RoomAds: '1042876068731830292',
        RoomPosts: '1042876051996549150',
        CeatogryPrivteRooms: '1309865368621289532',
        Giftsad: '1042876070141108326',
        Firstadcatagory: '1367660545825833010',
        CeatogryPrivteRoomad: '1042876028877553685',
        LogRoles: '1333606277690953738',
        Logmzad: '1333606277690953738',
        LogPosts: '1333606277690953738',
        LogAds: '1333606277690953738',
        LogBlacklist: '1333606277690953738',
        LogSpins: '1333606277690953738',
        LogPrivteRooms: '1333606277690953738',
        LogTranscreipt: '1042876120166563890',
        Logscammers: '1333606277690953738',
        LogOrders: '',
        WinLog: '1333606277690953738',
        Warns: '1042876085471293470',
        Orders: '1047987717948059678',
        Sug: '1042876114919489636',
        Feedback: '1042876113514397798',
        Tax: '1089312367810183239'

    },
    Tickets: {
        TicketSupport: true,
        TicketComplain: true,
        TicketsKdaa: true,
        TicketsMzad: true
    },

    ReportSettings: {
        ReportButtonRoleID: '1042876000771506316',
        ChannelID: '1217163888727031920'

    },
    BroadCast: {
        Tokens: ["لا تلعب فيها"],
    },
    CetagryTicket: {
        support: '1042876038146949230',
        Tasher: '1042876039216513034',
        Mzad: '1042876038146949230',
        complain: '1042876038146949230',
        spin: '1042876038146949230'
    },
    Admins: {
        DiscordStaff: '1042875969020641310',
        DiscordLeder: '1136025530358059039',
        Kdaa: '1042876000771506316',
        Mzad: '1042876001752981666'
    },
    Wasset: {
        wasset1cat: '1382088486902825151',
        wasset2cat: '1382088617752662076',
        wasset3cat: '1382088664905027727',
        wasset4cat: '1382088702146248744',
        wasset5cat: '1382088731577811045'
    },
    ServerInfo: {
        serverID: '1031233174434480293',
        line: 'https://media.discordapp.net/attachments/1237979197973069844/1279153968223752345/tbi2ccQ.gif?ex=67a5afb7&is=67a45e37&hm=03be004d7700ee20e8b7c2af70103dd5a12c57b72a6216a1d622640d0374d496&width=1100&height=52&',
        ApplyImage: 'https://media.discordapp.net/attachments/1237979197973069844/1279068646446075914/ap.png?ex=67a60901&is=67a4b781&hm=deb53d8db3d844878f99bc56cd5addbbd5a92b8d24694c59d6e77b56b8b2e38e&',
        Orders: 'https://media.discordapp.net/attachments/1237979197973069844/1279068646446075914/ap.png?ex=67a60901&is=67a4b781&hm=deb53d8db3d844878f99bc56cd5addbbd5a92b8d24694c59d6e77b56b8b2e38e&',
        tashfer: 'https://media.discordapp.net/attachments/1237979197973069844/1279068646446075914/ap.png?ex=67a60901&is=67a4b781&hm=deb53d8db3d844878f99bc56cd5addbbd5a92b8d24694c59d6e77b56b8b2e38e&',
        SpinImage: '',
        ScamImage: 'https://media.discordapp.net/attachments/1237979197973069844/1279068646446075914/ap.png?ex=67a60901&is=67a4b781&hm=deb53d8db3d844878f99bc56cd5addbbd5a92b8d24694c59d6e77b56b8b2e38e&',
    },  
    Apply: {
        MasoulKbool: 'ايدي الي يقدر يقبل و يرفض التقديمات',
        staff: {
            Room: 'ايدي الروم الي يروح فيها التقديم',
            Role: 'ايدي الرتبة الي راح تجيه',
            type: false, //هنا تحطها true لو عايز تفتح التقديم
        },
        Kdaa: {
            Room: 'ايدي الروم الي يروح فيها التقديمات',
            Role: 'ايدي الرتبة الي تحيه لما ينقبل',
            type: false,
        },
        Waset: {
            Room: 'ايدي الروم الي يروح فيها التقديمات',
            Role: 'ايدي الرتبة الي تحيه لما ينقبل',
            type: false,
        },
    },
    Fa7s: {
        staff: {
            ticket: 2500,
            warn: 1500,
        },
        Kdaa: {
            ticket: 4000,
        }
    },
    AutoLine: [
        "هنا تحط ايدي الرومات الي محتاج فيها اوتو لاين",
        "id",
        "Id",
        "Id",
        "Id",
        "Id",
        "Id",
        "Id",
        "Id"
    ],
    blacklist: {
        staff: '1042876018505039914',
        mazad: '1042876018505039914',
        tickets: '1042876018505039914',
    },
    Close_Open: {
        log: 'ايدي الروم يلي يرسل فيها الحاجة',
        refresh: true,
        Rooms: [
            "هنا تحط ايدي الرومات الي يقفل و يفتح رومات الشوب",
            "id",
            "Id",
            "Id",
            "Id",
            "Id",
            "Id",
            "Id",
            "Id"
        ]
        
    },
    
    
    Orders: {
        montgat: {
            role: '1042875975031074876',
            room: 'ايدي الروم الي يروح فيها طلبات المنتجات',
        },
        tsamem: {
            role: '1042875975031074876',
            room: 'ايدي الروم الي يروح فيها الطلبات التصاميم',
        },
        devss: {
            role: '1042875975031074876',
            room: 'ايدي روم المبرمجين يلي يروح فيها الطلبات',
        },
    },

};