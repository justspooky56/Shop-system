const {
    MessageActionRow, MessageSelectMenu, Modal, MessageEmbed,
    MessageButton, Permissions, TextInputComponent
} = require('discord.js');
const { client, dbTickets, settings } = require('../../index');
const ticketsDB = require('../../database/Tickets.json');

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton() && !interaction.isSelectMenu() && !interaction.isModalSubmit()) return;

    if (interaction.customId === 'SpinHelp') {
        const embed = new MessageEmbed()
            .setDescription('**مرحبا بك ايها الاداري في قايمة مساعد الاداره\nبرجاء اختيار المساعده التي تريدها**')
            .setColor('BLUE')
            .setThumbnail(interaction.guild.iconURL({ dynamic: true }));
        const row = new MessageActionRow().addComponents(
            new MessageSelectMenu()
                .setCustomId('AdminHelpMenu')
                .setPlaceholder('اختر نوع المساعده')
                .addOptions([
                    { label: 'استدعاء صاحب التذكره', value: 'call_owner' },
                    { label: 'اضافة شخص', value: 'add_user' },
                    { label: 'ازالة شخص', value: 'remove_user' },
                    { label: 'تغيير اسم التذكره', value: 'rename_ticket' },
                    { label: 'استدعاء عليا', value: 'call_leader' },
                    { label: 'اعاده تعيين القايمه', value: 'reset_menu' },
                ])
        );

        await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
    }

    // ========== 1. Call Ticket Owner ==========
    if (interaction.customId === 'AdminHelpMenu' && interaction.values[0] === 'call_owner') {
        const ticket = ticketsDB.Tickets_Spin.find(t => t.Ticket === interaction.channel.id);
        if (!ticket) return interaction.reply({ content: '❌ لم يتم العثور على بيانات التذكرة.', ephemeral: true });

        const owner = ticket.userid;
        const dmEmbed = new MessageEmbed()
            .setTitle('استدعاء')
            .setColor(settings.لون_الامبيد)
            .setDescription(`**مرحبا <@${owner}>،

                يرجى التوجه إلى [التذكرة](https://discord.com/channels/${interaction.guild.id}/${interaction.channel.id}) في أقرب وقت ممكن.
                
                المُستدعي: <@${interaction.member.id}>
                **`)
            .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
            .setColor('BLUE');

        const dmRow = new MessageActionRow().addComponents(
            new MessageButton()
                .setLabel('افتح التذكرة')
                .setStyle('LINK')
                .setURL(`https://discord.com/channels/${interaction.guild.id}/${interaction.channel.id}`)
        );

        const user = await client.users.fetch(owner).catch(() => null);
        if (user) await user.send({ embeds: [dmEmbed], components: [dmRow] }).catch(() => {});

        await interaction.reply({ content: `**تم استدعاء <@${owner}> بنجاح**`, ephemeral: true });

        const logEmbed = new MessageEmbed()
            .setTitle('استدعاء العضو')
            .setColor(settings.لون_الامبيد)
            .setDescription(`لقد تم استدعاء <@${owner}> بنجاح`)
            .setThumbnail(interaction.guild.iconURL({ dynamic: true }));

        await interaction.channel.send({ content: `<@${interaction.user.id}> || <@${owner}>`, embeds: [logEmbed] });
        await interaction.channel.send({ files: [settings.ServerInfo.line] });
    }

    // ========== 2 & 3. Add/Remove User ==========
    if (interaction.customId === 'AdminHelpMenu' && ['add_user', 'remove_user'].includes(interaction.values[0])) {
        const modal = new Modal()
            .setCustomId(interaction.values[0] === 'add_user' ? 'AddUserModal' : 'RemoveUserModal')
            .setTitle(interaction.values[0] === 'add_user' ? 'اضافة عضو' : 'ازالة عضو')
            .addComponents([
                new MessageActionRow().addComponents(
                    new TextInputComponent()
                        .setCustomId('targetUser')
                        .setLabel('اكتب ايدي العضو')
                        .setStyle('SHORT')
                        .setRequired(true)
                )
            ]);
        await interaction.showModal(modal);
    }

    if (interaction.customId === 'AddUserModal' || interaction.customId === 'RemoveUserModal') {
        const userid = interaction.fields.getTextInputValue('targetUser');
        const action = interaction.customId === 'AddUserModal' ? 'اضافة' : 'ازالة';
        const embed = new MessageEmbed()
            .setTitle(`${action} عضو الي التذكره`)
            .setColor(settings.لون_الامبيد)
            .setDescription(`لقد تم ${action === 'اضافة' ? 'اضافة العضو' : 'ازالة العضو'} الي التذكره <@${userid}>`)
            .setColor(action === 'اضافة' ? 'GREEN' : 'RED')
            .setThumbnail(interaction.guild.iconURL({ dynamic: true }));

        await interaction.reply({ content: `<@${interaction.user.id}> || <@${userid}>`, embeds: [embed] });
    }

    // ========== 4. Rename Ticket ==========
    if (interaction.customId === 'AdminHelpMenu' && interaction.values[0] === 'rename_ticket') {
        const modal = new Modal()
            .setCustomId('RenameTicket')
            .setTitle('تغيير اسم التذكره')
            .addComponents([
                new MessageActionRow().addComponents(
                    new TextInputComponent()
                        .setCustomId('newName')
                        .setLabel('اكتب الاسم الجديد')
                        .setStyle('SHORT')
                        .setRequired(true)
                )
            ]);
        await interaction.showModal(modal);
    }

    if (interaction.customId === 'RenameTicket') {
        const newName = interaction.fields.getTextInputValue('newName');
        await interaction.channel.setName(newName);
        const embed = new MessageEmbed()
            .setTitle('تغيير اسم التذكره')
            .setColor(settings.لون_الامبيد)
            .setDescription(`تم تغيير اسم التذكره الي \`${newName}\``)
            .setThumbnail(interaction.guild.iconURL({ dynamic: true }));
            await interaction.reply({ embeds: [embed], ephemeral: true });
            await interaction.channel.send({ files: [settings.ServerInfo.line] });
    }

    // ========== 5. Call Leader ==========
    if (interaction.customId === 'AdminHelpMenu' && interaction.values[0] === 'call_leader') {
        const modal = new Modal()
            .setCustomId('CallLeaderModal')
            .setTitle('سبب استدعاء عليا')
            .addComponents([
                new MessageActionRow().addComponents(
                    new TextInputComponent()
                        .setCustomId('reasonText')
                        .setLabel('اكتب سبب الاستدعاء')
                        .setStyle('PARAGRAPH')
                        .setRequired(true)
                )
            ]);
        await interaction.showModal(modal);
    }
    
    if (interaction.customId === 'CallLeaderModal') {
        const reason = interaction.fields.getTextInputValue('reasonText');
        await interaction.channel.setName('مطلوب عليا');
    
        const embed = new MessageEmbed()
            .setTitle('استدعاء عليا')
            .setDescription(`**الاداري: <@${interaction.user.id}>\nالسبب: ${reason}\n\nملاحظة برجاء الانتظار بدون منشن!**`)
            .setColor(settings.لون_الامبيد)
            .setThumbnail(interaction.guild.iconURL({ dynamic: true }));
    
        await interaction.reply({ content: `<@${interaction.user.id}> || <@${settings.Admins.DiscordLeder}>`, embeds: [embed] });
        await interaction.channel.send({ files: [settings.ServerInfo.line] });
    }

    // ========== 6. Reset Menu ==========
    if (interaction.customId === 'AdminHelpMenu' && interaction.values[0] === 'reset_menu') {
        const embed = new MessageEmbed()
            .setDescription('**مرحبا بك ايها الاداري في قايمة مساعد الاداره\nبرجاء اختيار المساعده التي تريدها**')
            .setColor(settings.لون_الامبيد)
            .setThumbnail(interaction.guild.iconURL({ dynamic: true }));

        const row = new MessageActionRow().addComponents(
            new MessageSelectMenu()
                .setCustomId('AdminHelpMenu')
                .setPlaceholder('اختر نوع المساعده')
                .addOptions([
                    { label: 'استدعاء صاحب التذكره', value: 'call_owner' },
                    { label: 'اضافة شخص', value: 'add_user' },
                    { label: 'ازالة شخص', value: 'remove_user' },
                    { label: 'تغيير اسم التذكره', value: 'rename_ticket' },
                    { label: 'استدعاء عليا', value: 'call_leader' },
                    { label: 'اعاده تعيين القايمه', value: 'reset_menu' },
                ])
        );

        await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
    }
});
