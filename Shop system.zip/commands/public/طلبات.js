const { Intents, Collection, Client, GuildMember, MessageActionRow, WebhookClient,MessagePayload, GatewayIntentBits, MessageSelectMenu, Modal, MessageEmbed,MessageButton, MessageAttachment, Permissions, TextInputComponent} = require('discord.js');
const { client, db , settings} = require('../../index');

const { createEmbed  } = require('../../function/function/Embed')


client.on('messageCreate', async message => {
    if (message.author.bot) return
    if (message.content == `${settings.prefix}setup-order`){

        if (!settings.Owners.includes(message.author.id)) return;


        const embed = createEmbed({
            interaction : message , 
            title : `يمكمك طلب ما تريد من هنا`, 
            description : `**
قوانين الطلبات

1-ممنوع طلب منتجات 18+
2-ممنوع طلب اعضاء او بارتنر
3-ممنوع طلب طرق نيترو و كريديت
4-ممنوع طلب اشياء في اماكن خطأ مثل : (تطلب نيترو في روم برمجيات او تصاميم)
5-ممنوع بيع اي شي           
**`, 
image : settings.ServerInfo.Orders
        })

        const buttons = new MessageActionRow().addComponents(

    new MessageSelectMenu()

        .setCustomId('SelectOrderType')

        .setPlaceholder('اختار نوع الطلب')

        .addOptions([

            { label: 'منتجات', value: 'Montgat' },

            { label: 'تصاميم', value: 'Tsamem' },

            { label: 'برمجيات', value: 'Devss' }

        ])

);

        await message.delete()
        await message.channel.send({embeds : [embed ], components : [buttons]})


    }
})


//// منتجات 
client.on('interactionCreate', async interaction => {
    if (!interaction.isButton() && !interaction.isModalSubmit()) return;

    const { customId } = interaction;

    if (customId == 'Montgat') {

        const OrderModal = new Modal()
            .setCustomId('OrderModalMontgat')
            .setTitle('اكمال عملية الطلب');
        const request = new TextInputComponent()
            .setCustomId('request')
            .setLabel("ما هو طلبك؟")
            .setStyle('PARAGRAPH');
        const firstActionRow = new MessageActionRow().addComponents(request);
        OrderModal.addComponents(firstActionRow);

        await interaction.showModal(OrderModal)
    } else if (customId == 'OrderModalMontgat') {
        const Order = interaction.fields.getTextInputValue(`request`);
        await interaction.reply({content : `تم ارسال طلبك بنجاح  | ✅`, ephemeral : true})

        const embed = createEmbed({
            interaction : interaction , 
            title : `طلب جديد`, 
            description: `- صاحب الطلب : ${interaction.user}\n\n\`\`\`${Order}\`\`\``,
        })

        const buttons = new MessageActionRow().addComponents(
            new MessageButton()
            .setCustomId('DeleteOrder')
            .setLabel('حذف الطلب')
            .setStyle('SECONDARY'), 
        )

        const Log = await interaction.guild.channels.fetch(settings.Orders.montgat.room)
        await Log.send({content : `<@&${settings.Orders.montgat.role}>` , embeds : [embed], components : [buttons]})
        await Log.send({files : [settings.ServerInfo.line]})

       
    }
});

//// برمجيات 
client.on('interactionCreate', async interaction => {
    if (!interaction.isButton() && !interaction.isModalSubmit()) return;

    const { customId } = interaction;

    if (customId == 'Devss') {

        const OrderModal = new Modal()
            .setCustomId('OrderModalDevss')
            .setTitle('اكمال عملية الطلب');
        const request = new TextInputComponent()
            .setCustomId('request')
            .setLabel("ما هو طلبك؟")
            .setStyle('PARAGRAPH');
        const firstActionRow = new MessageActionRow().addComponents(request);
        OrderModal.addComponents(firstActionRow);

        await interaction.showModal(OrderModal)
    } else if (customId == 'OrderModalDevss') {
        const Order = interaction.fields.getTextInputValue(`request`);
        await interaction.reply({content : `تم ارسال طلبك بنجاح  | ✅`, ephemeral : true})

        const embed = createEmbed({
            interaction : interaction , 
            title : `طلب جديد`, 
            description: `- صاحب الطلب : ${interaction.user}\n\n\`\`\`${Order}\`\`\``,
        })

        const buttons = new MessageActionRow().addComponents(
            new MessageButton()
            .setCustomId('DeleteOrder')
            .setLabel('حذف الطلب')
            .setStyle('SECONDARY'), 
        )
        const Log = await interaction.guild.channels.fetch(settings.Orders.devss.room)
        await Log.send({content : `<@&${settings.Orders.devss.role}>` , embeds : [embed] , components : [buttons]})
        await Log.send({files : [settings.ServerInfo.line]})

       
    }
});

//// تصاميم 

client.on('interactionCreate', async interaction => {
    if (!interaction.isButton() && !interaction.isModalSubmit()) return;

    const { customId } = interaction;

    if (customId == 'Tsamem') {

        const OrderModal = new Modal()
            .setCustomId('OrderModalTsamem')
            .setTitle('اكمال عملية الطلب');
        const request = new TextInputComponent()
            .setCustomId('request')
            .setLabel("ما هو طلبك؟")
            .setStyle('PARAGRAPH');
        const firstActionRow = new MessageActionRow().addComponents(request);
        OrderModal.addComponents(firstActionRow);

        await interaction.showModal(OrderModal)
    } else if (customId == 'OrderModalTsamem') {
        const Order = interaction.fields.getTextInputValue(`request`);
        await interaction.reply({content : `تم ارسال طلبك بنجاح  | ✅`, ephemeral : true})

        const embed = createEmbed({
            interaction : interaction , 
            title : `طلب جديد`, 
            description: `- صاحب الطلب : ${interaction.user}\n\n\`\`\`${Order}\`\`\``,
        })

        const buttons = new MessageActionRow().addComponents(
            new MessageButton()
            .setCustomId('DeleteOrder')
            .setLabel('حذف الطلب')
            .setStyle('SECONDARY'), 
        )
        const Log = await interaction.guild.channels.fetch(settings.Orders.tsamem.room)
        await Log.send({content : `<@&${settings.Orders.tsamem.role}>` , embeds : [embed], components: [buttons]})
        await Log.send({files : [settings.ServerInfo.line]})

       
    }
});




client.on('interactionCreate', async interaction => {
    if (!interaction.isButton()) return;
    if (interaction.customId !== 'DeleteOrder') return;
    if (!interaction.member.roles.cache.has(settings.Admins.DiscordStaff)) return;

    const userId = interaction.message.embeds[0]?.description?.match(/<@!?(\d+)>/)?.[1];

    if (!userId) return;

    const embed = new MessageEmbed()
        .setDescription(`**
اهلا بك عزيزي الاداري ${interaction.user} بـ ميوتات الطلبات .
يُرجى منك اختيار سبب الميوت لـ مخالفة الشخص بـ الميوت .
ولِـ استلامك نقطة من قسم نقاط ميوتات الطلبات .
**`)

        .setColor('YELLOW');
    const select = new MessageActionRow().addComponents(
        new MessageSelectMenu()
            .setCustomId(`MuteReason_${userId}`)
            .setPlaceholder('اختر سبب الميوت')
            .addOptions([
                { label: 'طلب بروم غلط', value: 'wrong_channel' },
                { label: 'طلب اعضاء أو بارتنرز', value: 'ads' },
                { label: 'طلب منتجات 18+', value: 'adult' },
                { label: 'طلب ممنوع', value: 'forbidden' },
                { label: 'بيع داخل الطلب', value: 'selling' },
            ])
    );

    await interaction.reply({ embeds: [embed], components: [select], ephemeral: true });

});

client.on('interactionCreate', async interaction => {
    if (!interaction.isSelectMenu()) return;
    if (!interaction.customId.startsWith('MuteReason_')) return;

    const userId = interaction.customId.split('_')[1];
    const member = await interaction.guild.members.fetch(userId).catch(() => null);
    if (!member) return interaction.reply({ content: 'لم أتمكن من العثور على العضو.', ephemeral: true });

    const reason = interaction.values[0];
    const muteTime = settings.Orders.Time[reason];
    if (!muteTime) return interaction.reply({ content: 'مدة الميوت غير معرفة في الإعدادات.', ephemeral: true });

    await member.roles.add(settings.MuteRoles.orderMute);

    setTimeout(async () => {
        await member.roles.remove(settings.MuteRoles.orderMute).catch(() => {});
    }, muteTime);

    await interaction.update({
    content: '**تم معاقبه العضو بنجاح**',
    components: [],
    embeds: [],
    ephemeral: true
});

const logChannel = await interaction.guild.channels.fetch(settings.Rooms.LogOrders).catch(() => null);
if (logChannel) {
    const targetUser = `<@${userId}> (\`${userId}\`)`;
    const staffUser = `<@${interaction.user.id}> (\`${interaction.user.id}\`)`;
    const originalMsg = interaction.message?.reference?.messageId 
        ? await interaction.channel.messages.fetch(interaction.message.reference.messageId).catch(() => null)
        : null;

    let orderContent = 'لم يتم استخراج الطلب.';
    let orderChannel = `<#${interaction.channel.id}>`;

    if (interaction.message.embeds[0]) {
        const embedDesc = interaction.message.embeds[0].description || '';
        const match = embedDesc.match(/```([^`]*)```/);
        if (match) {
            orderContent = match[1];
        }
    }

    const reasons = {
        wrong_channel: 'طلب بروم غلط',
        ads: 'طلب اعضاء أو بارتنرز',
        adult: 'طلب منتجات 18+',
        forbidden: 'طلب ممنوع',
        selling: 'بيع داخل الطلب'
    };

    const reasonLabel = reasons[reason] || 'غير معروف';

    const logEmbed = new MessageEmbed()
        .setTitle('** Add Mute Order !**')
        .setDescription(`**الشخص : ${targetUser}**\n** الاداري : ${staffUser}**\n<:rb3:1359000923204227235> **الطلب : ${orderContent}**\n**روم الطلب : ${orderChannel}**\n**سبب حذف الطلب : ${reasonLabel}**\n**تم إضافة الميوت في : <t:${Math.floor(Date.now() / 1000)}:R>**`)
        .setColor('RED');

    logChannel.send({ embeds: [logEmbed] }).catch(() => {});
}
});